N1Hub Theme (FSE)
Version: 0.1.0
Requires at least: WordPress 6.6
Requires PHP: 8.3
License: GPL-2.0-or-later
Purpose: Lean, clarity-first FSE theme for N1Hub.com.


